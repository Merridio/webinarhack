<footer id="wpdevart-footer">
	<p class="text-center">Powered by <a href="http://wpdevart.com/" target="_blank">Wpdevart</a>. All rights reserved</p>
</footer>