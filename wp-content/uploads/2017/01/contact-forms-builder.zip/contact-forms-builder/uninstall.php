<?php 
/*
	PRECATUIONS
	don't delete this file, this runs as a plugin is deleted
	as soon a user deletes plugin, all plugin related files and
	db tables will be deleted
*/

//	read table names from following require_once file
require_once ("wpdevart-inc/db-tables-config.php");

require_once ("functions.php");

//if uninstall not called from WordPress exit
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) exit();

function wpda_form_plugin_uninstall() {
	
	global $wpdb;
	global $wpda_form_table;
	
	/**
	*	remove all attachments of the form
	*/
	// remove attachemnts of submissions of current form 
		$attachment_fields_ids = $wpdb -> get_results ("SELECT id FROM " .$wpda_form_table['fields'] ." WHERE  fieldtype='file' ");
		if(!empty($attachment_fields_ids))
		{
			foreach($attachment_fields_ids as $row):
				$ids[] = $row->id;
			endforeach;
			
			if(count($ids)>1){
				$arr = implode(',',$ids);
				$attachment_fields_submit_values = $wpdb -> get_results ("SELECT field_value FROM " .$wpda_form_table['submissions'] ." WHERE fk_field_id IN ($arr) AND  field_value IS NOT NULL ");
			} else {
				$id = $ids[0];
				$attachment_fields_submit_values = $wpdb -> get_results ("SELECT field_value FROM " .$wpda_form_table['submissions'] ." WHERE fk_field_id = $id AND  field_value IS NOT NULL ");
			}
			
			 foreach($attachment_fields_submit_values as $row)
			 {
				$result =  $row->field_value; 
				//	get the site url with domain
				$site_url= get_site_url();
				// 	convert abs path to relative
				
				$rel_path=  str_replace($site_url,'',$result);
				if( file_exists(ABSPATH .$rel_path))
				{
					unlink(ABSPATH .$rel_path);
				}
			 }
		}
	
	//	remove styling of forms 
	if(get_option('wpdevart_forms_style')){
		delete_option('wpdevart_forms_style');
	}
	
	//drop tables
	
	$wpdb->query( "DROP TABLE IF EXISTS " .$wpda_form_table['submissions'] );
	$wpdb->query( "DROP TABLE IF EXISTS " .$wpda_form_table['submit_time'] );
	$wpdb->query( "DROP TABLE IF EXISTS " .$wpda_form_table['subfields'] );
	$wpdb->query( "DROP TABLE IF EXISTS " .$wpda_form_table['fields']);
	$wpdb->query( "DROP TABLE IF EXISTS " .$wpda_form_table['wpdevart_forms'] );
	
	if(get_option("wpdevart_forms_plugin_version")) {
		delete_option("wpdevart_forms_plugin_version");
	}
	
	// remove attachment folder
	$wp_upload_dir = wp_upload_dir();
	$wpdevart_forms_uploads_dir  = wpda_form_uploads_dir();
	
	//	Delete folder of for wpdevart-forms-attachments
	wpda_form_rrmdir($wp_upload_dir['basedir'].'/'.$wpdevart_forms_uploads_dir);  
}

wpda_form_plugin_uninstall();
?>