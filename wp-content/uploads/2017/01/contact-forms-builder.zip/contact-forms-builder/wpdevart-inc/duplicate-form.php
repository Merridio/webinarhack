<?php

/**
 * Duplicates Form by clicking duplicate icon. It'll duplicate 
 * all form structure and its relevant submission
 *
 * @package wpdevart Forms
 * @since	1.0
 */
 
$form_id = $_POST['formId'];
$form_record = $wpdb->get_row ($wpdb->prepare("SELECT * FROM ".$wpda_form_table['wpdevart_forms']." WHERE id =%d ",$form_id));

//	insert  copy of  form
$datetime = wpda_form_datetime(time()); 


$sql_select = $wpdb->prepare("SELECT 
						name, params, '" .$datetime ."'
			  	FROM  
						".$wpda_form_table['wpdevart_forms']."
			  	WHERE  id=%d ",$form_id);
			  
$sql_insert = "insert into ".$wpda_form_table['wpdevart_forms']." 
					(name, params , datetime)
					($sql_select) ";
			
$wpdb->query($sql_insert);

$newly_created_form_id = $wpdb->insert_id;

$new_form_name = wpda_form_append_integer_similiar_names($form_record->name);
$arrUpdate['name'] = $new_form_name;		
$wpdb->update($wpda_form_table['wpdevart_forms'], $arrUpdate, array("id" => $newly_created_form_id));

// inset copy of form fields
$sql_select = $wpdb->prepare("SELECT 
					label, fieldtype, placeholder , is_required, $newly_created_form_id, position
			   FROM  
					".$wpda_form_table['fields']."
			   WHERE  fk_form_id=%d",$form_id);
			   
$sql_insert = "insert into ".$wpda_form_table['fields']." 
					(label, fieldtype, placeholder , is_required, fk_form_id, position)
					($sql_select)";
					
$wpdb->query($sql_insert);

//inset copy of fields's subfields
$sql_select = $wpdb->prepare("SELECT 
					$newly_created_form_id, fk_field_id, label,selected_value 
			   FROM  
					".$wpda_form_table['subfields']."
			   WHERE  fk_form_id=%d",$form_id);
			   
$sql_insert = "insert into ".$wpda_form_table['subfields']." 
					(fk_form_id, fk_field_id, label, selected_value)
					($sql_select)";
					
$wpdb->query($sql_insert);

$current_form_field_ids = $wpdb->get_results($wpdb->prepare("SELECT id FROM ".$wpda_form_table['fields']." WHERE fk_form_id =%d ",$form_id));
$newly_created_form_field_ids = $wpdb->get_results($wpdb->prepare("SELECT id FROM ".$wpda_form_table['fields']." WHERE fk_form_id =%d ",$newly_created_form_id));

foreach($current_form_field_ids as $key => $current_form_field_id) {
	//	we will now update update subfields
	$arrUpdate = NULL;
	$arrUpdate['fk_field_id'] = $newly_created_form_field_ids[$key]->id;
	$wpdb->update($wpda_form_table['subfields'], $arrUpdate, array("fk_field_id"=>$current_form_field_id->id, "fk_form_id"=>$newly_created_form_id));
}

//	if form custom styling exists , duplicate form styling for new form
if(get_option('wpdevart_forms_style')) {
	$wpda_form_styles = get_option('wpdevart_forms_style');
	//	search current form styling in option
	$form_style_found = wpda_form_form_styling_exists($form_id, get_option('wpdevart_forms_style')) ;
	if( !empty($form_style_found) ) {
		$wpda_form_styles[$newly_created_form_id] = $wpda_form_styles[$form_id];
		
		//-- we do not need attributes which are not related to styling
		if(isset($wpda_form_styles[$newly_created_form_id]['form_id']))
			unset($wpda_form_styles[$newly_created_form_id]['form_id']);
		if(isset($wpda_form_styles[$newly_created_form_id]['action']))
			unset($wpda_form_styles[$newly_created_form_id]['form_id']);
		
		update_option('wpdevart_forms_style', $wpda_form_styles);
	}
}
if($wpdb->last_error) {
	print_r($wpdb->last_error);
}
?>