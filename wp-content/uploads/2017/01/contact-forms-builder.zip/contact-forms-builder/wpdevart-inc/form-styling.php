<?php
/*
  This file includes custom styling for forms
  There are multiple ways in which css  styles  are applied to our form , that are :
    1 . general theme styling for all forms (included in theme css file)
	2 . form skins , red,green etc
    3 . general styling for all forms (created by our plugin) [static  form_id = -1 ]
		--NOTE--  please note that form with id = -1 do not exists in database . its just a static id that
		      	  is used only in styling purposes 
				  general form styling is been DEPRECATED
    4 . Every form created by wpdevart Forms plugin can have its own styling 
 
  NOTE: please note that custom styling for wpdevart Forms is stored in wordpress 
  		table " wp_options " with our defined option of "wpdevart_forms_style"
*/

global $wpdb;	   //	database interaction
global $wpda_form_table; //	plugins tables info
 
//	Determines whether style settings were restored to their default values or not
$reset_settings_flag = 0;

//	determines whether style settings were updated or not
$update_settings_flag = 0;

$first_form_id_row = $wpdb->get_row("SELECT id FROM ".$wpda_form_table['wpdevart_forms']." limit 1 ");

if($first_form_id_row) {
	
	$first_form_id = $first_form_id_row->id;
	//$wpdb->last_error;
	 
	
	$form_id = ( isset($_GET['form_id']) ) ? (int) $_GET['form_id'] : $first_form_id ;
	
	// reset current form's style to default 
	
	if(isset($_POST['btn_reset_form_style'])) {
		$reset_settings_flag = 1;
		if( get_option('wpdevart_forms_style') ) {
			/*
					IMPORTATN NOTE:
					===============
					Restoring to default = Delete styling record = unset form index in option wpdevart_forms_style
					
					Let say we have to restore form with id = 2 (index[2])styling to its default
					
					e.g, array([1]=>array(wpda_form_top_border_thickness = 10px ,form_background = '#101' etc), // style for form with id = 2 
							   [2]=>array(wpda_form_top_border_thickness = 10px ,form_background = '#101' etc)) // style for form with id = 2  [to be restored to default]
							   [3]=>array(wpda_form_top_border_thickness = 10px ,form_background = '#101' etc)) // style form form with id = 3
							   
				   For restoring form style to its default value we check whehter that forms's styling exists in option  'wpdevart_forms_style' or not
					
				  if forms styling is found,unset $form_id's index
					  e.g, array([1]=>array(wpda_form_top_border_thickness = 10px ,form_background = '#101' etc), // style form form with id = 1
								  // index[2] is been unset (index  = form id)
								 [3]=>array(wpda_form_top_border_thickness = 10px ,form_background = '#101' etc)) // style form form with id = 3
								 
			 */
			
			
			$wpda_form_styles = get_option('wpdevart_forms_style');
			// search current form styling in option
			$form_style_found = wpda_form_form_styling_exists ( $form_id, get_option('wpdevart_forms_style')) ;
			if(!empty($form_style_found)) {
				$style_del_flag = 1;
				unset($wpda_form_styles[$form_id]);
				
				// There must be atleast one style record in option, if not delete the option
				if( count($wpda_form_styles) >= 1 ) {
				
					update_option('wpdevart_forms_style', $wpda_form_styles);
				} else {
					
					delete_option('wpdevart_forms_style');
				}
			}
		}
	}
	
	//getting all forms styling 
	$styles = get_option('wpdevart_forms_style');
	// current form style
	$wpda_form_style = (isset($styles[$form_id])) ? $styles[$form_id]: NULL;
	
	//clean value 
	if($wpda_form_style) {
		foreach($wpda_form_style as $key  => $value) {
			$wpda_form_style[$key] = stripslashes_deep(esc_html( $value ));
		}
	}
}
?>
<div id="wpdevart">
<div id="wpdevart-forms">
	<form class="wpdevart-general-form"  name="styling_tab_form" method="post" <?php if(isset($form_id)){ echo "data-attr = {$form_id} ";} ?>  action="">
		<?php require_once( wpda_form_PLUGIN_DIR .'/wpdevart-layout/header.php');?>
		<?php require_once( wpda_form_PLUGIN_DIR .'/wpdevart-layout/sidebar.php');?>
			<main class="pull-left">
				<div id="update-status" class="modal fade">
				  <div class="modal-dialog">
					<div class="modal-content">
						<h2> <i class="fa fa-check"></i>Settings saved successfully</h2>
					</div><!-- /.modal-content -->
				  </div><!-- /.modal-dialog -->
				</div><!-- /update-status -->
				<div id="reset-status" class="modal fade">
				  <div class="modal-dialog">
					<div class="modal-content">
						<h2><i class="fa fa-check"></i> Settings have been reset </h2>
					</div><!-- /.modal-content -->
				  </div><!-- /.modal-dialog -->
				</div><!-- /reset-status -->
				<div id="setting-saved" class="modal fade">
				  <div class="modal-dialog">
					<div class="modal-content">
						<h2><i class="fa fa-check"></i>Settings have been saved </h2>
					</div><!-- /.modal-content -->
				  </div><!-- /.modal-dialog -->
				</div><!-- /reset-status -->
				<?php require_once( wpda_form_PLUGIN_DIR .'/wpdevart-layout/help.php');?>
                <?php $wpdevart_forms = $wpdb->get_results("SELECT * FROM ".$wpda_form_table['wpdevart_forms']."  ");?>
				
                <div class="tab-content wpdevart-tabs"> 
					<img class="wpdevart_pro" src="<?php echo wpda_form_PLUGIN_URI ?>/images/styling_1.jpg">
                    <img class="wpdevart_pro" src="<?php echo wpda_form_PLUGIN_URI ?>/images/styling_2.jpg">
                    <img class="wpdevart_pro" src="<?php echo wpda_form_PLUGIN_URI ?>/images/styling_3.jpg">
                    <img class="wpdevart_pro" src="<?php echo wpda_form_PLUGIN_URI ?>/images/styling_4.jpg">
                    <img class="wpdevart_pro" src="<?php echo wpda_form_PLUGIN_URI ?>/images/styling_5.jpg">
				</div><!-- .tab-content -->
			</main><!-- / main .pull-left -->
		<div class="clearfix"></div>
		</div><!-- / .options-area -->
		<?php require_once( wpda_form_PLUGIN_DIR .'/wpdevart-layout/footer.php');?>
	</form><!-- #wpdevart-general-form -->
</div><!-- / #wpdevart-forms -->
</div><!-- / wpdevart -->
<script>

	// do not remove isDirty and changesSaved variables they are being used in ajax javascript file
	var isDirty = 0;
	var changesSaved = 0;	
	
	// Alert user about  unsaved changes before leaving the page
	var formElement = jQuery("form[name='styling_tab_form']"),
	origForm = formElement.serialize();

	jQuery('#chooseFormForStyling').change(function () {
		var optionSelected = jQuery(this).find("option:selected");
		var formId  = optionSelected.val();
		location.href="<?php echo admin_url("admin.php?page=".$this->slug['styling']."&form_id="); ?>"+formId;	
	});
	
	window.onbeforeunload = function() {
		if (formElement.serialize() !== origForm && changesSaved == 0) {
			return 'You have unsaved changes! If you leave this page, your changes will be lost.';
		}
	};
	
</script>

<?php if( $reset_settings_flag == 1 ){ ?>
<script>
	jQuery(document).on("ready", function(e) {
	//jQuery(document).ready(function(e) {
	jQuery('#reset-status').modal('show');
	setTimeout(function(){ jQuery('#reset-status').modal('hide'); }, 2000);
}); 			
</script>
<?php  }?>