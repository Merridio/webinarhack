=== Contact Forms ===
Contributors: wpdevart
Donate link: http://wpdevart.com/wordpress-contact-form-plugin/
Tags:  form, forms, form builder, contact form, wordpress contact form, contact forms, form manager, contact us, custom form, contact form builder, form creator 
Requires at least: 3.4.0
Tested up to: 4.6.1
Stable tag: 1.0.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Contact Form plugin is an nice and handy tool for creating different types of contact forms on your WordPress websites. Use our WordPress Contact Form builder plugin for building intuitive and functional contact us pages. 

== Description ==

Contact Form builder plugin is the most important part of any WordPress website. All want to see nice and functional Contatc Form on their website. So we tried to give our users easy and user friendly plugin for building contact forms on their websites. We hope you will like WpDevArt contact form plugin.  

### View our Contact Form plugin Demo page here: 

[Demo](http://demo.wpdevart.com/demo-contact-form-bulder/)

WpDevArt Contact Form have a lot of useful and great features, here are some features of our plugin. 

### Features of WpDevArt Contact Form plugin

*   **Easy install and use**
*   **Works perfectly with all versions of WordPress**
*   **Fully Responsive Contact Form Builder**
*   **Add Unlimited form fields for your contact form**
*   **Required option for any form field you need**
*   **You can easily move form fields positions**
*   **16 different form types for contact form**
*   **Ability to insert Text field**
*   **Ability to insert Email field**
*   **Ability to insert URL field**
*   **Ability to insert Telephone number field**
*   **Ability to insert Date/Calendar field**
*   **Ability to insert Upload File field**
*   **Ability to insert Password field**
*   **Ability to insert Text Area field**
*   **Ability to insert Radio Button field**
*   **Ability to insert Check Box field**
*   **Ability to insert Dropdown List field**
*   **Ability to insert Heading field**
*   **Ability to insert Separator/Divider field**
*   **Ability to insert reCaptcha field**
*   **Ability to insert Google Map field**

You can upgrade WpDevArt Contact Form plugin to [WpDevArt Contact Form Pro](http://wpdevart.com/wordpress-contact-form-plugin/) to add other important features.

### The features of WpDevArt Contact Form Pro

*   **Fully Design customization**
*   **More then 25 nice themes**
*   **Fully Import/Export Contact Forms**
*   **Forms duplication**

### If you found any bug or have a question contact us at support@wpdevart.com.

== Installation ==

### First of all download the WpDevArt Contact Form plugin ZIP file.  
Installing the plugin  

1. Log in to your WordPress admin panel.   
2. Go to WordPress Plugins page and click on Add New button, then Upload the .zip file that you downloaded.
3. Then click "Install Now", after that activate the WpDevArt Contact Form plugin.     
4. From the left panel of Dashboard, click on the gear icon - WpDevArt Forms link to customize the plugin
	  
That's all, now you can create contact forms for your website. If any problem apear, contact us at [support@wpdevart.com](mailto:support@wpdevart.com).

== Frequently Asked Questions ==

WpDevArt Contact Form builder plugin have user friendly interface, but here you can see some frequently asked questions that will help you.

= What files I need to upload for installing the plugin =

You need to select the .zip file only, there is no need to extract the zip file, just upload it.

== Screenshots ==

1.  **WpDevArt Contact Form** Front-end    
3.  **WpDevArt Contact Form** Back-end     
   
== Changelog ==

= 1.0.0 =

*  Initial version.


